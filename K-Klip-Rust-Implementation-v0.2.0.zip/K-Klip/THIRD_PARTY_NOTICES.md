# Third-party software and assets

K-Klip's original source code is licensed under MIT. This does not relicense third-party tools, libraries, codecs, models, or downloaded media.

Before enabling or distributing each integration, record its exact version, license, source URL, modifications, and required notices here. Planned integrations requiring review include:

- FFmpeg (license depends on build configuration and enabled components; LGPL/GPL implications must be checked).
- yt-dlp (license and distribution obligations must be checked for the selected integration method).
- whisper.cpp and model weights (code and model terms must be reviewed separately).
- ONNX Runtime or Candle (selected runtime and transitive dependencies must be audited).
- Pixabay API and downloaded media (API terms and asset-specific license/attribution conditions apply).
- AndroidX, Jetpack Compose, JNI support libraries, and Rust crates (retain their respective notices).

No third-party implementation is represented as K-Klip-authored code. Generate an SBOM and license report before release.
