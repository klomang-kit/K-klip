# Build status — 2026-11-18

## Implemented in source (not yet compile-verified)
- Rust workspace and modular library + CLI entry point.
- Local project JSON persistence with atomic temp-file replacement and project listing.
- Timeline tracks, clip validation, add/remove/move/split and duration calculations.
- FFprobe metadata inspection; FFmpeg thumbnail generation, audio extraction, denoise/loudness normalization, SRT burn-in, sequential single-video-track MP4 export and sequential per-clip batch export.
- Scene-change extraction and silence interval detection using FFmpeg filters.
- Whisper CLI SRT/TXT transcription adapter.
- yt-dlp command integration for best/1080p/720p/480p/audio retrieval.
- Pixabay video search API and HTTPS media download.
- JNI functions for engine version, probing, project create/list, scene detection and provider actions.
- Compose Android dashboard with SAF video import/copy, project create/list and JNI metadata probing (probe requires an Android-accessible FFprobe binary, which is not bundled).
- Direct FFmpeg smoke tests passed for multi-source concat with differing resolution/FPS and missing audio, plus SRT burn-in. These do not replace Rust/Android integration tests.
- Android Gradle task that invokes cargo-ndk for ARM ABIs.

## Not implemented yet
- Face detection/tracking, smart reframing and automatic zoom.
- Semantic/model-driven highlight ranking (the current score helper is a transparent heuristic, not AI inference).
- Multi-track video compositing, audio mixing, transitions, keyframes, overlays and a full interactive timeline UI.
- Subtitle style/animation editor and subtitle translation.
- Background batch queue, cancellation, retry/resume and progress callbacks.
- B-roll semantic matching from transcript, attribution/license metadata UI and automatic timeline insertion.
- Android-ready FFmpeg/FFprobe, yt-dlp runtime and whisper-cli/model packaging. Desktop command adapters are not sufficient for Android execution.
- Android Keystore-encrypted Pixabay key UI and robust project migrations/recovery.

## Verification blockers
The authoring environment has Java and Git but no Rust compiler/Cargo, Gradle executable, Android SDK/NDK or adb. Rust formatting, dependency resolution, compilation, unit tests, APK assembly and device tests were not run. Source is therefore an implementation-in-progress snapshot, not a tested or release-ready APK. Run `cargo fmt --all -- --check`, `cargo test --workspace`, then `scripts/build-android.sh` in a fully provisioned environment.

## GitHub status
The repository `klomang-kit/K-klip` was discovered, but the connected GitHub integration returned HTTP 403 `Resource not accessible by integration` on a repository write. No push was completed. Grant the GitHub app write access to this repository or reconnect the integration, then retry.
