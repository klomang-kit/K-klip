# K-Klip technical architecture

## Design rules
1. Rust is the source of truth for product rules, project schema, timeline math, job orchestration, and data validation.
2. Kotlin is limited to Android lifecycle, Compose rendering, Storage Access Framework, permissions, MediaCodec/Surface integration, notifications, and Keystore access.
3. No proprietary K-Klip server. Provider access is direct from device to YouTube-compatible retrieval tooling and Pixabay.
4. Every long-running job is cancellable, reports progress, and writes recoverable local state.
5. Feature modules expose interfaces so codec/model implementations can be replaced without rewriting product logic.

## Planned modules
- `project`: versioned project schema, migrations, autosave and recovery.
- `timeline`: tracks, clips, transitions, effects, keyframes and deterministic time math.
- `media`: probing, thumbnailing, decoding, encoding and export orchestration.
- `ai`: transcription, highlight ranking, silence detection, face/object tracking and reframing.
- `network`: provider adapters, retry policy, resumable downloads, API-key protection and redacted diagnostics.
- `storage`: SQLite metadata, app-private cache, SAF document references and cleanup policy.

## Android/Rust boundary
Use a narrow JNI API with opaque job/project handles and serialized DTOs. Do not pass large video/audio buffers through JSON or JNI byte arrays; use file descriptors, shared memory or native surfaces where appropriate. Keep ABI-specific Rust builds reproducible for arm64-v8a and optionally x86_64 emulator.

## Privacy and security
- API keys are held in Android Keystore-backed encrypted storage.
- Never log credentials, signed URLs, or private media paths unnecessarily.
- Downloads and projects remain local unless the user explicitly invokes an external provider.
- Request Android media permissions only when needed; prefer SAF document selection.
