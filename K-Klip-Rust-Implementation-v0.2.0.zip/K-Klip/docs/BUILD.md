# Build setup

The Android Gradle project is configured for Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Compose, compile/target SDK 35, and min SDK 26. A Gradle wrapper is not bundled in this environment. Install a compatible Android SDK and NDK, install Rust plus cargo-ndk, then add the JNI/NDK build integration before expecting the Android app to invoke Rust.

The current Compose shell does not yet load the Rust shared library. This is intentionally deferred until the JNI ABI and Android ABI matrix are implemented and tested.
