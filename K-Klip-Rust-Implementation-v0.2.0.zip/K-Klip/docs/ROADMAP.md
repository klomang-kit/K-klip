# K-Klip implementation roadmap

## Current source milestone
The Rust project/timeline domain, FFmpeg/FFprobe CLI adapters, scene/silence analysis, Whisper CLI adapter, yt-dlp CLI adapter, Pixabay API client, basic JNI entry points and Android project/media shell are implemented in source. They have not been compile- or device-verified in this environment.

## Milestone 1 — Build integrity
- Install Rust stable, Cargo, rustfmt, clippy, Android SDK/NDK and Gradle.
- Resolve compiler and dependency errors; run unit tests and clippy.
- Add Android CI for `arm64-v8a` and `armeabi-v7a`.
- Bundle Android-native FFmpeg/FFprobe with a verified license configuration.

## Milestone 2 — Android media pipeline
- Replace subprocess-only media calls on Android with a bundled, ABI-compatible media runtime or Android MediaCodec adapter.
- Add SAF persisted URI grants, file descriptor handling and app-private cache lifecycle.
- Implement thumbnail extraction, preview decoder and export job progress/cancellation.

## Milestone 3 — Full editor
- Multi-track compositing, audio mixing, transitions, keyframes, overlays and interactive timeline.
- Subtitle editor, style presets, karaoke timing and translation workflow.
- Export profiles, background queue, batch export and recovery.

## Milestone 4 — AI features
- Whisper model management and inference runtime integration.
- Face/object detector and tracker with subject-aware 9:16/1:1/16:9 reframing.
- Model-assisted highlight ranking, hook detection and silence-aware clip assembly.
- Transcript-to-B-roll matching and user-reviewed stock selection.

## Milestone 5 — Network and security
- Android-native yt-dlp deployment strategy compatible with platform policy and provider terms.
- Pixabay key storage using Android Keystore-backed encryption.
- Resumable downloads, bounded retries, rate limiting, progress and cancellation.
- Source/license metadata for every downloaded stock asset.

## Release gate
No feature is marked complete until it has unit/integration tests, Android device validation on supported ABIs, error handling, and license review. Third-party code, binaries, model weights and media are tracked separately from MIT-licensed K-Klip code.
