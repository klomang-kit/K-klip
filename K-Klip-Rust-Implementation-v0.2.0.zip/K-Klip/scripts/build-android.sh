#!/usr/bin/env bash
set -euo pipefail

command -v rustup >/dev/null || { echo "rustup is required" >&2; exit 1; }
command -v cargo-ndk >/dev/null || { echo "Install cargo-ndk: cargo install cargo-ndk" >&2; exit 1; }
command -v gradle >/dev/null || { echo "Gradle is required (or use Android Studio)" >&2; exit 1; }
rustup target add aarch64-linux-android armv7-linux-androideabi
cargo ndk -t arm64-v8a -t armeabi-v7a -o app/src/main/jniLibs build --release -p kklip-engine
gradle :app:assembleDebug
