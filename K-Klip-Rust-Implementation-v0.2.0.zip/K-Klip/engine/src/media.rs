use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::path::{Path,PathBuf};
use crate::{error::{KklipError,Result}, process};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct MediaInfo { pub id:String, pub path:String, pub duration_ms:u64, pub width:u32, pub height:u32, pub frame_rate_num:u32, pub frame_rate_den:u32, pub has_audio:bool }
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)] pub enum ExportContainer { Mp4 }
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)] pub enum VideoCodec { H264, H265 }
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExportSettings { pub width:u32, pub height:u32, pub fps:u32, pub bitrate_kbps:u32, pub codec:VideoCodec, pub container:ExportContainer }
impl Default for ExportSettings { fn default()->Self{Self{width:1080,height:1920,fps:30,bitrate_kbps:8000,codec:VideoCodec::H264,container:ExportContainer::Mp4}} }
impl ExportSettings { pub fn validate(&self)->Result<()> { if self.width==0||self.height==0||self.width%2!=0||self.height%2!=0{return Err(KklipError::Invalid("Resolusi harus positif dan genap untuk encoding H.264/H.265".into()));} if !(1..=120).contains(&self.fps){return Err(KklipError::Invalid("FPS harus 1–120".into()));} if self.bitrate_kbps<250{return Err(KklipError::Invalid("Bitrate minimal 250 kbps".into()));} Ok(()) } }

pub fn probe(path:impl AsRef<Path>)->Result<MediaInfo>{
    let path=path.as_ref(); if !path.is_file(){return Err(KklipError::Invalid(format!("File media tidak ditemukan: {}",path.display())));}
    let path_string=path.to_string_lossy().into_owned();
    let output=process::run("ffprobe",["-v","error","-show_streams","-show_format","-of","json",path_string.as_str()])?;
    let root:Value=serde_json::from_slice(&output.stdout)?;
    let streams=root.get("streams").and_then(Value::as_array).ok_or_else(||KklipError::Invalid("ffprobe tidak mengembalikan daftar stream".into()))?;
    let video=streams.iter().find(|s|s.get("codec_type").and_then(Value::as_str)==Some("video")).ok_or_else(||KklipError::Invalid("File tidak memiliki stream video".into()))?;
    let audio=streams.iter().any(|s|s.get("codec_type").and_then(Value::as_str)==Some("audio"));
    let duration=root.pointer("/format/duration").and_then(Value::as_str).and_then(|s|s.parse::<f64>().ok()).unwrap_or(0.0);
    let (num,den)=video.get("r_frame_rate").and_then(Value::as_str).and_then(parse_ratio).unwrap_or((0,1));
    Ok(MediaInfo{id:stable_id(path),path:path.canonicalize().unwrap_or_else(|_|path.to_path_buf()).to_string_lossy().into_owned(),duration_ms:(duration.max(0.0)*1000.0) as u64,width:video.get("width").and_then(Value::as_u64).unwrap_or(0) as u32,height:video.get("height").and_then(Value::as_u64).unwrap_or(0) as u32,frame_rate_num:num,frame_rate_den:den,has_audio:audio})
}
fn parse_ratio(s:&str)->Option<(u32,u32)>{let(a,b)=s.split_once('/')?;Some((a.parse().ok()?,b.parse().ok()?))}
pub fn stable_id(path:&Path)->String{ let text=path.to_string_lossy(); let mut hash=14695981039346656037u64; for b in text.bytes(){hash^=b as u64;hash=hash.wrapping_mul(1099511628211);} format!("media-{hash:016x}") }
pub fn make_thumbnail(input:impl AsRef<Path>,output:impl AsRef<Path>,at_ms:u64,width:u32)->Result<PathBuf>{
    let output=output.as_ref(); if let Some(parent)=output.parent(){std::fs::create_dir_all(parent)?;}
    let input_string=input.as_ref().to_string_lossy().into_owned(); let output_string=output.to_string_lossy().into_owned(); let seek=format!("{:.3}",at_ms as f64/1000.0); let filter=format!("scale={width}:-2");
    process::run("ffmpeg",["-hide_banner","-loglevel","error","-y","-ss",seek.as_str(),"-i",input_string.as_str(),"-frames:v","1","-vf",filter.as_str(),output_string.as_str()])?; Ok(output.to_path_buf())
}
pub fn extract_audio(input:impl AsRef<Path>,output:impl AsRef<Path>)->Result<PathBuf>{let output=output.as_ref(); if let Some(p)=output.parent(){std::fs::create_dir_all(p)?;} let input_string=input.as_ref().to_string_lossy().into_owned(); let output_string=output.to_string_lossy().into_owned(); process::run("ffmpeg",["-hide_banner","-loglevel","error","-y","-i",input_string.as_str(),"-vn","-ac","1","-ar","16000","-c:a","pcm_s16le",output_string.as_str()])?;Ok(output.to_path_buf())}

pub fn export_video(clips:&[crate::timeline::Clip],settings:&ExportSettings,output:impl AsRef<Path>)->Result<PathBuf>{
    settings.validate()?; if clips.is_empty(){return Err(KklipError::Invalid("Timeline video kosong".into()));}
    let mut ordered=clips.to_vec(); ordered.sort_by_key(|c|c.timeline_start_ms);
    let mut cursor=0u64; let mut infos=Vec::new();
    for c in &ordered { if c.timeline_start_ms!=cursor{return Err(KklipError::Invalid("Ekspor saat ini mensyaratkan klip video berurutan tanpa celah atau overlap".into()));} let info=probe(&c.media_id)?; if c.source_out_ms>info.duration_ms{return Err(KklipError::Invalid(format!("Batas klip {} melewati durasi sumber",c.id)));} cursor=c.timeline_end_ms(); infos.push(info); }
    let output=output.as_ref(); if let Some(p)=output.parent(){std::fs::create_dir_all(p)?;}
    let mut args:Vec<String>=vec!["-hide_banner".into(),"-y".into()];
    for (c,info) in ordered.iter().zip(infos.iter()) { args.push("-i".into());args.push(info.path.clone()); if !info.has_audio {args.extend(["-f".into(),"lavfi".into(),"-t".into(),format!("{:.3}",c.duration_ms() as f64/1000.0),"-i".into(),"anullsrc=channel_layout=stereo:sample_rate=48000".into()]);} }
    let mut graph=String::new(); let mut concat_inputs=String::new(); let mut input_index=0usize;
    for (i,(c,info)) in ordered.iter().zip(infos.iter()).enumerate(){
        graph.push_str(&format!("[{input_index}:v:0]trim=start={:.3}:end={:.3},setpts=PTS-STARTPTS,scale={}:{}:force_original_aspect_ratio=decrease,pad={}:{}:(ow-iw)/2:(oh-ih)/2:color=black,fps={},setsar=1,format=yuv420p[v{i}];",c.source_in_ms as f64/1000.0,c.source_out_ms as f64/1000.0,settings.width,settings.height,settings.width,settings.height,settings.fps));
        let audio_index=if info.has_audio{input_index}else{input_index+1};
        let audio_start=if info.has_audio{c.source_in_ms}else{0}; let audio_end=if info.has_audio{c.source_out_ms}else{c.duration_ms()};
        graph.push_str(&format!("[{audio_index}:a:0]atrim=start={:.3}:end={:.3},asetpts=PTS-STARTPTS,aresample=48000[a{i}];",audio_start as f64/1000.0,audio_end as f64/1000.0));
        concat_inputs.push_str(&format!("[v{i}][a{i}]")); input_index+=if info.has_audio{1}else{2};
    }
    graph.push_str(&format!("{concat_inputs}concat=n={}:v=1:a=1[outv][outa]",ordered.len()));
    args.extend(["-filter_complex".into(),graph,"-map".into(),"[outv]".into(),"-map".into(),"[outa]".into()]);
    let (encoder,preset)=match settings.codec{VideoCodec::H264|VideoCodec::H265=>(if settings.codec==VideoCodec::H264{"libx264"}else{"libx265"},"medium")};
    args.extend(["-c:v".into(),encoder.into(),"-preset".into(),preset.into(),"-b:v".into(),format!("{}k",settings.bitrate_kbps),"-c:a".into(),"aac".into(),"-b:a".into(),"192k".into(),"-movflags".into(),"+faststart".into(),output.to_string_lossy().into_owned()]);
    let refs:Vec<&str>=args.iter().map(String::as_str).collect(); process::run("ffmpeg",refs)?; Ok(output.to_path_buf())
}

/// Applies FFmpeg denoising and loudness normalization to an audio file.
pub fn enhance_audio(input:impl AsRef<Path>,output:impl AsRef<Path>)->Result<PathBuf>{
    let output=output.as_ref();if let Some(parent)=output.parent(){std::fs::create_dir_all(parent)?;}
    let input_string=input.as_ref().to_string_lossy().into_owned(); let output_string=output.to_string_lossy().into_owned();
    process::run("ffmpeg",["-hide_banner","-loglevel","error","-y","-i",input_string.as_str(),"-vn","-af","afftdn=nf=-25,loudnorm=I=-16:TP=-1.5:LRA=11","-c:a","aac","-b:a","192k",output_string.as_str()])?;
    Ok(output.to_path_buf())
}

/// Burns an existing SRT subtitle file into a video using FFmpeg's subtitles filter.
pub fn burn_subtitles(input:impl AsRef<Path>,srt:impl AsRef<Path>,output:impl AsRef<Path>)->Result<PathBuf>{
    let srt=srt.as_ref();if !srt.is_file(){return Err(KklipError::Invalid(format!("File subtitle tidak ditemukan: {}",srt.display())));}
    let output=output.as_ref();if let Some(parent)=output.parent(){std::fs::create_dir_all(parent)?;}
    let escaped = srt.to_string_lossy().replace('\\', "\\\\").replace(':', "\\:").replace('\'', "\\'");
    let input_string=input.as_ref().to_string_lossy().into_owned(); let output_string=output.to_string_lossy().into_owned(); let filter=format!("subtitles='{escaped}'");
    process::run("ffmpeg",["-hide_banner","-loglevel","error","-y","-i",input_string.as_str(),"-vf",filter.as_str(),"-c:v","libx264","-preset","medium","-crf","20","-c:a","copy",output_string.as_str()])?;
    Ok(output.to_path_buf())
}

/// Exports one timeline clip as an independent MP4 file.
pub fn export_clip(clip:&crate::timeline::Clip,settings:&ExportSettings,output:impl AsRef<Path>)->Result<PathBuf>{
    settings.validate()?;
    let info=probe(&clip.media_id)?;
    if clip.source_out_ms>info.duration_ms || clip.source_out_ms<=clip.source_in_ms { return Err(KklipError::Invalid("Rentang sumber klip berada di luar durasi media".into())); }
    let output=output.as_ref();if let Some(parent)=output.parent(){std::fs::create_dir_all(parent)?;}
    let input=info.path;let output_string=output.to_string_lossy().into_owned();
    let start=format!("{:.3}",clip.source_in_ms as f64/1000.0);let end=format!("{:.3}",clip.source_out_ms as f64/1000.0);
    let scale=format!("scale={}:{}:force_original_aspect_ratio=decrease,pad={}:{}:(ow-iw)/2:(oh-ih)/2,fps={},setsar=1,format=yuv420p",settings.width,settings.height,settings.width,settings.height,settings.fps);
    let duration=format!("{:.3}",clip.duration_ms() as f64/1000.0);
    let mut args=vec!["-hide_banner".to_string(),"-y".into(),"-ss".into(),start,"-i".into(),input,"-t".into(),duration];
    if !info.has_audio { args.extend(["-f".into(),"lavfi".into(),"-t".into(),format!("{:.3}",clip.duration_ms() as f64/1000.0),"-i".into(),"anullsrc=channel_layout=stereo:sample_rate=48000".into()]); }
    args.extend(["-vf".into(),scale,"-map".into(),"0:v:0".into(),"-map".into(),if info.has_audio{"0:a:0".into()}else{"1:a:0".into()},"-c:v".into(),match settings.codec{VideoCodec::H264=>"libx264".into(),VideoCodec::H265=>"libx265".into()},"-preset".into(),"medium".into(),"-b:v".into(),format!("{}k",settings.bitrate_kbps),"-c:a".into(),"aac".into(),"-b:a".into(),"192k".into(),"-shortest".into(),"-movflags".into(),"+faststart".into(),output_string]);
    process::run("ffmpeg",args)?;Ok(output.to_path_buf())
}

/// Exports every clip in a track to a separate numbered MP4 file.
pub fn export_batch(clips:&[crate::timeline::Clip],settings:&ExportSettings,directory:impl AsRef<Path>)->Result<Vec<PathBuf>>{
    if clips.is_empty(){return Err(KklipError::Invalid("Tidak ada klip untuk batch export".into()));}
    let directory=directory.as_ref();std::fs::create_dir_all(directory)?;let mut results=Vec::with_capacity(clips.len());
    for (index,clip) in clips.iter().enumerate(){let safe_id:String=clip.id.chars().map(|c|if c.is_ascii_alphanumeric()||c=='-'||c=='_'{c}else{'_'}).collect();let output=directory.join(format!("{:03}-{}.mp4",index+1,safe_id));results.push(export_clip(clip,settings,output)?);}
    Ok(results)
}
