use serde::{Deserialize, Serialize};
use thiserror::Error;

#[derive(Debug, Error, PartialEq, Eq)]
pub enum TimelineError {
    #[error("Durasi klip harus lebih dari nol")] ZeroDuration,
    #[error("Waktu akhir sumber harus lebih besar dari waktu awal")] InvalidSourceRange,
    #[error("Track tidak ditemukan: {0}")] TrackNotFound(String),
    #[error("Klip tidak ditemukan")] ClipNotFound,
    #[error("Posisi timeline tidak valid")] InvalidPosition,
    #[error("ID media tidak boleh kosong")] EmptyMediaId,
}
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct Clip { pub id: String, pub media_id: String, pub source_in_ms: u64, pub source_out_ms: u64, pub timeline_start_ms: u64 }
impl Clip {
    pub fn new(id: impl Into<String>, media_id: impl Into<String>, source_in_ms: u64, source_out_ms: u64, timeline_start_ms: u64) -> Result<Self, TimelineError> {
        let id=id.into();
        if id.trim().is_empty() { return Err(TimelineError::InvalidPosition); }
        if source_out_ms == source_in_ms { return Err(TimelineError::ZeroDuration); }
        if source_out_ms < source_in_ms { return Err(TimelineError::InvalidSourceRange); }
        let media_id = media_id.into(); if media_id.trim().is_empty() { return Err(TimelineError::EmptyMediaId); }
        Ok(Self { id, media_id, source_in_ms, source_out_ms, timeline_start_ms })
    }
    pub fn duration_ms(&self) -> u64 { self.source_out_ms - self.source_in_ms }
    pub fn timeline_end_ms(&self) -> u64 { self.timeline_start_ms.saturating_add(self.duration_ms()) }
}
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct Track { pub id: String, pub kind: TrackKind, pub clips: Vec<Clip> }
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum TrackKind { Video, Audio, Subtitle, Overlay }
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq, Eq)]
pub struct Timeline { pub tracks: Vec<Track> }
impl Timeline {
    pub fn add_track(&mut self, id: impl Into<String>, kind: TrackKind) -> Result<(), TimelineError> {
        let id=id.into(); if id.trim().is_empty() || self.tracks.iter().any(|t|t.id==id) { return Err(TimelineError::InvalidPosition); }
        self.tracks.push(Track{id,kind,clips:Vec::new()}); Ok(())
    }
    pub fn add_clip(&mut self, track_id: &str, clip: Clip) -> Result<(), TimelineError> {
        let track=self.tracks.iter_mut().find(|t|t.id==track_id).ok_or_else(||TimelineError::TrackNotFound(track_id.into()))?;
        if track.clips.iter().any(|c|c.id==clip.id) { return Err(TimelineError::InvalidPosition); }
        track.clips.push(clip); track.clips.sort_by_key(|c|c.timeline_start_ms); Ok(())
    }
    pub fn remove_clip(&mut self, track_id:&str, clip_id:&str)->Result<Clip,TimelineError>{
        let track=self.tracks.iter_mut().find(|t|t.id==track_id).ok_or_else(||TimelineError::TrackNotFound(track_id.into()))?;
        let index=track.clips.iter().position(|c|c.id==clip_id).ok_or(TimelineError::ClipNotFound)?; Ok(track.clips.remove(index))
    }
    pub fn move_clip(&mut self, track_id:&str, clip_id:&str, position_ms:u64)->Result<(),TimelineError>{
        let track=self.tracks.iter_mut().find(|t|t.id==track_id).ok_or_else(||TimelineError::TrackNotFound(track_id.into()))?;
        let clip=track.clips.iter_mut().find(|c|c.id==clip_id).ok_or(TimelineError::ClipNotFound)?; clip.timeline_start_ms=position_ms;
        track.clips.sort_by_key(|c|c.timeline_start_ms); Ok(())
    }
    pub fn split_clip(&mut self, track_id:&str, clip_id:&str, at_source_ms:u64, right_id:impl Into<String>)->Result<(),TimelineError>{
        let track=self.tracks.iter_mut().find(|t|t.id==track_id).ok_or_else(||TimelineError::TrackNotFound(track_id.into()))?;
        let index=track.clips.iter().position(|c|c.id==clip_id).ok_or(TimelineError::ClipNotFound)?;
        let original=track.clips[index].clone(); let right_id=right_id.into();
        if at_source_ms<=original.source_in_ms || at_source_ms>=original.source_out_ms || right_id.trim().is_empty() || track.clips.iter().any(|c|c.id==right_id) { return Err(TimelineError::InvalidPosition); }
        track.clips[index].source_out_ms=at_source_ms;
        let right=Clip::new(right_id,original.media_id,at_source_ms,original.source_out_ms,original.timeline_start_ms+(at_source_ms-original.source_in_ms))?;
        track.clips.insert(index+1,right); Ok(())
    }
    pub fn duration_ms(&self)->u64 { self.tracks.iter().flat_map(|t|&t.clips).map(Clip::timeline_end_ms).max().unwrap_or(0) }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn split_clip_preserves_duration_and_places_second_half() {
        let mut timeline=Timeline::default();
        timeline.add_track("video",TrackKind::Video).unwrap();
        timeline.add_clip("video",Clip::new("left","source.mp4",0,10_000,0).unwrap()).unwrap();
        timeline.split_clip("video","left",4_000,"right").unwrap();
        let clips=&timeline.tracks[0].clips;
        assert_eq!(clips.iter().map(Clip::duration_ms).sum::<u64>(),10_000);
        assert_eq!(clips[1].timeline_start_ms,4_000);
    }
    #[test]
    fn moving_clip_keeps_order_sorted() {
        let mut timeline=Timeline::default();
        timeline.add_track("video",TrackKind::Video).unwrap();
        timeline.add_clip("video",Clip::new("a","a.mp4",0,1000,0).unwrap()).unwrap();
        timeline.add_clip("video",Clip::new("b","b.mp4",0,1000,2000).unwrap()).unwrap();
        timeline.move_clip("video","b",0).unwrap();
        assert_eq!(timeline.tracks[0].clips[0].id,"b");
    }
}
