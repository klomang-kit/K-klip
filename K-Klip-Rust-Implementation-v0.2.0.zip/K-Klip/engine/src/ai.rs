use std::{path::{Path,PathBuf},process::Command};
use crate::{error::{KklipError,Result},process};

#[derive(Debug,Clone,Copy,Default)] pub struct HighlightSignals{pub speech_energy:f32,pub audio_energy:f32,pub scene_change:f32,pub keyword_match:f32}
pub fn score_highlight(s:&HighlightSignals)->f32{let clamp=|v:f32|if v.is_finite(){v.clamp(0.0,1.0)}else{0.0};(0.30*clamp(s.speech_energy)+0.25*clamp(s.audio_energy)+0.20*clamp(s.scene_change)+0.25*clamp(s.keyword_match)).clamp(0.0,1.0)}
#[derive(Debug,Clone,PartialEq)] pub struct CandidateMoment{pub start_ms:u64,pub end_ms:u64,pub score:f32}
pub fn rank_moments(mut moments:Vec<CandidateMoment>)->Vec<CandidateMoment>{moments.sort_by(|a,b|b.score.total_cmp(&a.score).then(a.start_ms.cmp(&b.start_ms)));moments}

pub fn detect_scenes(video:impl AsRef<Path>,minimum_score:f32,window_ms:u64)->Result<Vec<CandidateMoment>>{
    if window_ms==0 || !(0.05..=0.95).contains(&minimum_score){return Err(KklipError::Invalid("Ambang scene harus 0.05–0.95".into()));}
    let path=video.as_ref();let path_string=path.to_string_lossy().into_owned();let filter=format!("select='gt(scene,{minimum_score})',showinfo");
    process::require_tool("ffmpeg")?;let output=Command::new("ffmpeg").args(["-hide_banner","-i",path_string.as_str(),"-vf",filter.as_str(),"-an","-f","null","-"]).output()?;
    if !output.status.success(){return Err(KklipError::Command{program:"ffmpeg".into(),status:output.status,stderr:String::from_utf8_lossy(&output.stderr).into_owned()});}
    let log=String::from_utf8_lossy(&output.stderr);let mut moments=Vec::new();
    for line in log.lines().filter(|l|l.contains("pts_time:")){if let Some(raw)=line.split("pts_time:").nth(1).and_then(|s|s.split_whitespace().next()){if let Ok(seconds)=raw.parse::<f64>(){let center=(seconds.max(0.0)*1000.0) as u64;let half=window_ms/2;moments.push(CandidateMoment{start_ms:center.saturating_sub(half),end_ms:center.saturating_add(half),score:minimum_score});}}}
    moments.sort_by_key(|m|m.start_ms);moments.dedup_by(|a,b|a.start_ms.abs_diff(b.start_ms)<window_ms/2);Ok(moments)
}

pub fn detect_silence(video:impl AsRef<Path>,noise_db:i8,minimum_seconds:f32)->Result<Vec<(u64,u64)>>{
    if !(-90..=-5).contains(&noise_db)||!minimum_seconds.is_finite()||minimum_seconds<=0.0{return Err(KklipError::Invalid("Parameter silence tidak valid".into()));}
    let path=video.as_ref();let path_string=path.to_string_lossy().into_owned();let filter=format!("silencedetect=noise={noise_db}dB:d={minimum_seconds}");process::require_tool("ffmpeg")?;
    let output=Command::new("ffmpeg").args(["-hide_banner","-i",path_string.as_str(),"-af",filter.as_str(),"-f","null","-"]).output()?;
    if !output.status.success(){return Err(KklipError::Command{program:"ffmpeg".into(),status:output.status,stderr:String::from_utf8_lossy(&output.stderr).into_owned()});}
    let log=String::from_utf8_lossy(&output.stderr);let mut start=None;let mut ranges=Vec::new();
    for line in log.lines(){if let Some(v)=line.split("silence_start:").nth(1).and_then(|s|s.split_whitespace().next()).and_then(|s|s.parse::<f64>().ok()){start=Some(v);} if let Some(end)=line.split("silence_end:").nth(1).and_then(|s|s.split_whitespace().next()).and_then(|s|s.parse::<f64>().ok()){if let Some(begin)=start.take(){ranges.push(((begin*1000.0) as u64,(end*1000.0) as u64));}}}
    Ok(ranges)
}

pub fn transcribe_whisper(audio:impl AsRef<Path>,model:impl AsRef<Path>,output_prefix:impl AsRef<Path>)->Result<PathBuf>{
    if !model.as_ref().is_file(){return Err(KklipError::Invalid(format!("Model Whisper tidak ditemukan: {}",model.as_ref().display())));}
    let audio=audio.as_ref();if !audio.is_file(){return Err(KklipError::Invalid("File audio tidak ditemukan".into()));}
    let prefix=output_prefix.as_ref();if let Some(p)=prefix.parent(){std::fs::create_dir_all(p)?;}
    let model_string=model.as_ref().to_string_lossy().into_owned();let audio_string=audio.to_string_lossy().into_owned();let prefix_string=prefix.to_string_lossy().into_owned();
    process::run("whisper-cli",["-m",model_string.as_str(),"-f",audio_string.as_str(),"-osrt","-otxt","-of",prefix_string.as_str()])?;
    let srt=prefix.with_extension("srt");if !srt.is_file(){return Err(KklipError::Invalid("Whisper selesai tetapi file SRT tidak dihasilkan".into()));}Ok(srt)
}

pub fn transcript_keywords(text:&str,limit:usize)->Vec<String>{
    const STOP:&[&str]=&["yang","dan","di","ke","dari","untuk","ini","itu","ada","adalah","the","a","an","is","are","to","of","in","on","for","with","and","or"];
    let mut counts=std::collections::HashMap::<String,usize>::new();for word in text.split(|c:char|!c.is_alphanumeric()).map(|w|w.to_lowercase()).filter(|w|w.len()>2&&!STOP.contains(&w.as_str())){*counts.entry(word).or_default()+=1;}
    let mut pairs:Vec<_>=counts.into_iter().collect();pairs.sort_by(|a,b|b.1.cmp(&a.1).then(a.0.cmp(&b.0)));pairs.into_iter().take(limit).map(|p|p.0).collect()
}
