//! Clean-room Rust core for K-Klip. Media, project, AI analysis and provider
//! integrations are implemented here; Android is an optional presentation layer.
pub mod ai;
pub mod android;
pub mod error;
pub mod media;
pub mod network;
pub mod process;
pub mod project;
pub mod timeline;

pub const ENGINE_NAME:&str="K-Klip Rust Engine";
pub const ENGINE_VERSION:&str=env!("CARGO_PKG_VERSION");

#[cfg(test)] mod tests {
    use crate::{ai::{self,HighlightSignals},timeline::{Clip,Timeline,TrackKind}};
    #[test] fn highlight_score_is_bounded(){let score=ai::score_highlight(&HighlightSignals{speech_energy:1.4,audio_energy:0.8,scene_change:0.7,keyword_match:1.0});assert!((0.0..=1.0).contains(&score));}
    #[test] fn timeline_rejects_zero_duration_clip(){assert!(Clip::new("c","m",10,10,0).is_err());}
    #[test] fn timeline_split_preserves_total_duration(){let mut t=Timeline::default();t.add_track("v",TrackKind::Video).unwrap();t.add_clip("v",Clip::new("a","file.mp4",0,10000,0).unwrap()).unwrap();t.split_clip("v","a",4000,"b").unwrap();assert_eq!(t.tracks[0].clips.iter().map(Clip::duration_ms).sum::<u64>(),10000);assert_eq!(t.tracks[0].clips[1].timeline_start_ms,4000);}
    #[test] fn timeline_move_sorts_clips(){let mut t=Timeline::default();t.add_track("v",TrackKind::Video).unwrap();t.add_clip("v",Clip::new("a","a.mp4",0,1000,0).unwrap()).unwrap();t.add_clip("v",Clip::new("b","b.mp4",0,1000,2000).unwrap()).unwrap();t.move_clip("v","b",0).unwrap();assert_eq!(t.tracks[0].clips[0].id,"b");}
    #[test] fn keyword_extraction_ignores_common_words(){let words=ai::transcript_keywords("Ini adalah video tentang Rust dan video editing",5);assert!(words.contains(&"video".to_string()));assert!(!words.contains(&"adalah".to_string()));}
    #[test] fn provider_secret_is_redacted(){assert!(crate::network::redact_url("https://example.test/?key=abc&q=cat").contains("key=[REDACTED]"));}
}
