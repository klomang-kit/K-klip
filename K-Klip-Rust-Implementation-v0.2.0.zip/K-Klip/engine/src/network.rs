use serde::{Deserialize,Serialize};
use std::{fs::File,io::{Read,Write},path::{Path,PathBuf}};
use crate::{error::{KklipError,Result},process};

#[derive(Debug,Clone,Copy,PartialEq,Eq)] pub enum Provider{Youtube,Pixabay}
#[derive(Debug,Clone,Copy,PartialEq,Eq)] pub enum NetworkState{Idle,Resolving,Downloading,Completed,Failed}
#[derive(Debug,Clone)] pub struct DownloadProgress{pub state:NetworkState,pub received_bytes:u64,pub total_bytes:Option<u64>}
impl DownloadProgress{pub fn fraction(&self)->Option<f32>{let total=self.total_bytes?;if total==0{return None;}Some((self.received_bytes as f64/total as f64).clamp(0.0,1.0) as f32)}}
#[derive(Debug,Clone,Serialize,Deserialize)] pub struct PixabayVideo{pub id:u64,pub page_url:String,pub user:String,pub duration:u32,pub tags:String,pub preview_url:String,pub video_url:String,pub width:u32,pub height:u32}
#[derive(Debug,Deserialize)] struct PixabayResponse{hits:Vec<PixabayHit>}
#[derive(Debug,Deserialize)] struct PixabayHit{id:u64,#[serde(rename="pageURL")] page_url:String,user:String,duration:u32,tags:String,videos:PixabayVariants}
#[derive(Debug,Deserialize)] struct PixabayVariants{large:Option<PixabayFile>,medium:Option<PixabayFile>,small:Option<PixabayFile>,tiny:Option<PixabayFile>}
#[derive(Debug,Deserialize)] struct PixabayFile{url:String,width:u32,height:u32}

pub fn download_youtube(url:&str,directory:impl AsRef<Path>,format:&str)->Result<PathBuf>{
    if !(url.starts_with("https://")||url.starts_with("http://")){return Err(KklipError::Invalid("URL YouTube harus berupa HTTP(S)".into()));}
    if !["best","1080p","720p","480p","audio"].contains(&format){return Err(KklipError::Invalid("Format harus best, 1080p, 720p, 480p, atau audio".into()));}
    std::fs::create_dir_all(directory.as_ref())?;
    let template=directory.as_ref().join("%(title).160B [%(id)s].%(ext)s");
    let template_string=template.to_string_lossy().into_owned();
    let selector=match format{"audio"=>"bestaudio/best","1080p"=>"bv*[height<=1080]+ba/b[height<=1080]","720p"=>"bv*[height<=720]+ba/b[height<=720]","480p"=>"bv*[height<=480]+ba/b[height<=480]",_=>"bv*+ba/b"};
    let mut args=vec!["--no-playlist","--newline","--progress","--format",selector,"--output",template_string.as_str()];
    if format=="audio"{args.extend(["--extract-audio","--audio-format","mp3"]);} else {args.extend(["--merge-output-format","mp4"]);}
    args.push(url);
    process::run("yt-dlp",args)?;
    Ok(directory.as_ref().to_path_buf())
}

pub fn search_pixabay(api_key:&str,query:&str,per_page:u8)->Result<Vec<PixabayVideo>>{
    if api_key.trim().is_empty(){return Err(KklipError::Invalid("Pixabay API key wajib diisi".into()));}
    if query.trim().is_empty(){return Err(KklipError::Invalid("Kata kunci pencarian wajib diisi".into()));}
    let count=per_page.clamp(3,50);
    let count_string=count.to_string();
    let response=reqwest::blocking::Client::builder().user_agent("K-Klip/0.1 (+local video editor)").build()?.get("https://pixabay.com/api/videos/").query(&[("key",api_key),("q",query),("per_page",count_string.as_str()),("safesearch","true")]).send()?.error_for_status()?;
    let data:PixabayResponse=response.json()?;
    Ok(data.hits.into_iter().filter_map(|h|{
        let file=h.videos.large.clone().or(h.videos.medium.clone()).or(h.videos.small.clone()).or(h.videos.tiny.clone())?;
        let preview=h.videos.small.clone().or(h.videos.tiny.clone()).map(|v|v.url).unwrap_or_else(||file.url.clone());
        Some(PixabayVideo{id:h.id,page_url:h.page_url,user:h.user,duration:h.duration,tags:h.tags,preview_url:preview,video_url:file.url,width:file.width,height:file.height})
    }).collect())
}

pub fn download_url(url:&str,destination:impl AsRef<Path>)->Result<PathBuf>{
    if !url.starts_with("https://"){return Err(KklipError::Invalid("Unduhan provider harus menggunakan HTTPS".into()));}
    let destination=destination.as_ref(); if let Some(parent)=destination.parent(){std::fs::create_dir_all(parent)?;}
    let mut response=reqwest::blocking::Client::new().get(url).send()?.error_for_status()?;
    let temp=destination.with_extension("download-part"); let mut file=File::create(&temp)?; let mut buffer=[0u8;64*1024];
    loop{let n=response.read(&mut buffer)?;if n==0{break;}file.write_all(&buffer[..n])?;}
    file.sync_all()?;std::fs::rename(&temp,destination)?;Ok(destination.to_path_buf())
}

pub fn redact_url(input:&str)->String{
    let Some((base,query))=input.split_once('?')else{return input.to_owned()};
    let safe=query.split('&').map(|part|{let key=part.split('=').next().unwrap_or("");if ["key","token","access_token","api_key"].iter().any(|s|key.eq_ignore_ascii_case(s)){format!("{key}=[REDACTED]")}else{part.to_owned()}}).collect::<Vec<_>>().join("&");format!("{base}?{safe}")
}
