use std::{ffi::OsStr, path::Path, process::{Command, Output}};
use crate::error::{KklipError, Result};

pub fn executable_exists(program: &str) -> bool {
    let candidate = Path::new(program);
    if candidate.components().count() > 1 { return candidate.is_file(); }
    std::env::var_os("PATH").map(|paths| std::env::split_paths(&paths).any(|p| p.join(program).is_file())).unwrap_or(false)
}

pub fn run<I, S>(program: &str, args: I) -> Result<Output>
where I: IntoIterator<Item = S>, S: AsRef<OsStr> {
    if !executable_exists(program) { return Err(KklipError::MissingTool(program.to_owned())); }
    let output = Command::new(program).args(args).output()?;
    if !output.status.success() {
        return Err(KklipError::Command {
            program: program.to_owned(), status: output.status,
            stderr: String::from_utf8_lossy(&output.stderr).trim().to_owned(),
        });
    }
    Ok(output)
}

pub fn run_to_file<I, S>(program: &str, args: I) -> Result<Output>
where I: IntoIterator<Item = S>, S: AsRef<OsStr> { run(program, args) }

pub fn require_tool(program: &str) -> Result<()> {
    if executable_exists(program) { Ok(()) } else { Err(KklipError::MissingTool(program.to_owned())) }
}
