//! Small JNI boundary. Large media payloads stay in files; only paths and compact JSON cross JNI.
use jni::{objects::{JClass,JString},sys::jstring,JNIEnv};
use serde_json::json;
use std::path::PathBuf;
use crate::{ai,media,network,project::{Project,ProjectStore}};

fn read_string(env:&mut JNIEnv<'_>,value:JString<'_>)->std::result::Result<String,String>{env.get_string(&value).map(|s|s.into()).map_err(|e|e.to_string())}
fn result_string(env:&mut JNIEnv<'_>,value:String)->jstring{env.new_string(value).map(|s|s.into_raw()).unwrap_or(std::ptr::null_mut())}
fn json_result<T:serde::Serialize>(result:crate::error::Result<T>)->String{match result{Ok(value)=>json!({"ok":true,"data":value}).to_string(),Err(error)=>json!({"ok":false,"error":error.to_string()}).to_string()}}

#[no_mangle] pub extern "system" fn Java_com_klomang_klip_NativeEngine_nativeVersion(mut env:JNIEnv<'_>,_class:JClass<'_>)->jstring{result_string(&mut env,format!("{} {}",crate::ENGINE_NAME,crate::ENGINE_VERSION))}
#[no_mangle] pub extern "system" fn Java_com_klomang_klip_NativeEngine_nativeProbe(mut env:JNIEnv<'_>,_class:JClass<'_>,path:JString<'_>)->jstring{
    let value=match read_string(&mut env,path){Ok(p)=>json_result(media::probe(p)),Err(e)=>json!({"ok":false,"error":e}).to_string()};result_string(&mut env,value)
}
#[no_mangle] pub extern "system" fn Java_com_klomang_klip_NativeEngine_nativeCreateProject(mut env:JNIEnv<'_>,_class:JClass<'_>,root:JString<'_>,id:JString<'_>,name:JString<'_>)->jstring{
    let result:crate::error::Result<String>=(||{let root=read_string(&mut env,root).map_err(crate::error::KklipError::Invalid)?;let id=read_string(&mut env,id).map_err(crate::error::KklipError::Invalid)?;let name=read_string(&mut env,name).map_err(crate::error::KklipError::Invalid)?;let store=ProjectStore::new(PathBuf::from(root))?;let mut project=Project::new(id,name);let path=store.save(&mut project)?;Ok(json!({"id":project.id,"name":project.name,"path":path.to_string_lossy()}).to_string())})();result_string(&mut env,json_result(result))
}
#[no_mangle] pub extern "system" fn Java_com_klomang_klip_NativeEngine_nativeListProjects(mut env:JNIEnv<'_>,_class:JClass<'_>,root:JString<'_>)->jstring{
    let result:crate::error::Result<serde_json::Value>=(||{let root=read_string(&mut env,root).map_err(crate::error::KklipError::Invalid)?;let store=ProjectStore::new(PathBuf::from(root))?;Ok(serde_json::to_value(store.list()?)?)})();result_string(&mut env,json_result(result))
}
#[no_mangle] pub extern "system" fn Java_com_klomang_klip_NativeEngine_nativeDetectScenes(mut env:JNIEnv<'_>,_class:JClass<'_>,path:JString,threshold:f32)->jstring{
    let result:crate::error::Result<serde_json::Value>=(||{let path=read_string(&mut env,path).map_err(crate::error::KklipError::Invalid)?;Ok(serde_json::to_value(ai::detect_scenes(path,threshold,15000)?)?)})();result_string(&mut env,json_result(result))
}
#[no_mangle] pub extern "system" fn Java_com_klomang_klip_NativeEngine_nativeYoutubeDownload(mut env:JNIEnv<'_>,_class:JClass<'_>,url:JString<'_>,directory:JString<'_>,format:JString<'_>)->jstring{
    let result:crate::error::Result<String>=(||{let url=read_string(&mut env,url).map_err(crate::error::KklipError::Invalid)?;let directory=read_string(&mut env,directory).map_err(crate::error::KklipError::Invalid)?;let format=read_string(&mut env,format).map_err(crate::error::KklipError::Invalid)?;Ok(network::download_youtube(&url,directory,&format)?.to_string_lossy().into_owned())})();result_string(&mut env,json_result(result))
}
#[no_mangle] pub extern "system" fn Java_com_klomang_klip_NativeEngine_nativePixabaySearch(mut env:JNIEnv<'_>,_class:JClass<'_>,key:JString<'_>,query:JString<'_>)->jstring{
    let result:crate::error::Result<serde_json::Value>=(||{let key=read_string(&mut env,key).map_err(crate::error::KklipError::Invalid)?;let query=read_string(&mut env,query).map_err(crate::error::KklipError::Invalid)?;Ok(serde_json::to_value(network::search_pixabay(&key,&query,20)?)?)})();result_string(&mut env,json_result(result))
}
