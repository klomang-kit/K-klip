use serde::{Deserialize, Serialize};
use std::{fs, path::{Path, PathBuf}, time::{SystemTime, UNIX_EPOCH}};
use crate::{error::{KklipError, Result}, timeline::Timeline};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct Project {
    pub schema_version: u32,
    pub id: String,
    pub name: String,
    pub created_at_unix_ms: u64,
    pub updated_at_unix_ms: u64,
    pub timeline: Timeline,
}
impl Project {
    pub fn new(id: impl Into<String>, name: impl Into<String>) -> Self {
        let now = now_ms();
        Self { schema_version: 1, id: id.into(), name: name.into(), created_at_unix_ms: now, updated_at_unix_ms: now, timeline: Timeline::default() }
    }
    pub fn touch(&mut self) { self.updated_at_unix_ms = now_ms(); }
}

#[derive(Debug, Clone)]
pub struct ProjectStore { root: PathBuf }
impl ProjectStore {
    pub fn new(root: impl Into<PathBuf>) -> Result<Self> { let root = root.into(); fs::create_dir_all(&root)?; Ok(Self { root }) }
    pub fn root(&self) -> &Path { &self.root }
    pub fn project_path(&self, id: &str) -> Result<PathBuf> {
        if id.is_empty() || !id.chars().all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_') { return Err(KklipError::Invalid("ID proyek hanya boleh berisi huruf, angka, - dan _".into())); }
        Ok(self.root.join(format!("{id}.kklip.json")))
    }
    pub fn save(&self, project: &mut Project) -> Result<PathBuf> {
        project.touch();
        let path = self.project_path(&project.id)?;
        let temp = path.with_extension("json.tmp");
        let bytes = serde_json::to_vec_pretty(project)?;
        fs::write(&temp, bytes)?;
        fs::rename(&temp, &path)?;
        Ok(path)
    }
    pub fn load(&self, id: &str) -> Result<Project> {
        let path = self.project_path(id)?;
        if !path.exists() { return Err(KklipError::ProjectNotFound(path)); }
        Ok(serde_json::from_slice(&fs::read(path)?)?)
    }
    pub fn list(&self) -> Result<Vec<ProjectSummary>> {
        let mut projects = Vec::new();
        for entry in fs::read_dir(&self.root)? {
            let path = entry?.path();
            if path.extension().and_then(|x| x.to_str()) != Some("json") || !path.file_name().and_then(|x| x.to_str()).unwrap_or("").ends_with(".kklip.json") { continue; }
            let project: Project = serde_json::from_slice(&fs::read(&path)?)?;
            projects.push(ProjectSummary { id: project.id, name: project.name, updated_at_unix_ms: project.updated_at_unix_ms, path });
        }
        projects.sort_by(|a,b| b.updated_at_unix_ms.cmp(&a.updated_at_unix_ms));
        Ok(projects)
    }
}
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProjectSummary { pub id: String, pub name: String, pub updated_at_unix_ms: u64, pub path: PathBuf }
pub fn now_ms() -> u64 { SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_millis() as u64 }

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn project_store_round_trip_and_list() {
        let root=std::env::temp_dir().join(format!("kklip-test-{}",now_ms()));
        let store=ProjectStore::new(&root).unwrap();
        let mut project=Project::new("test-1","Test Project");
        store.save(&mut project).unwrap();
        let loaded=store.load("test-1").unwrap();
        assert_eq!(loaded.name,"Test Project");
        assert_eq!(store.list().unwrap().len(),1);
        std::fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn project_id_cannot_escape_store_directory() {
        let root=std::env::temp_dir().join(format!("kklip-path-test-{}",now_ms()));
        let store=ProjectStore::new(&root).unwrap();
        assert!(store.project_path("../outside").is_err());
        std::fs::remove_dir_all(root).unwrap();
    }
}
