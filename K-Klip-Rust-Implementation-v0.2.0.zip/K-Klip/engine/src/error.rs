use std::{io, path::PathBuf, process::ExitStatus};
use thiserror::Error;

#[derive(Debug, Error)]
pub enum KklipError {
    #[error("I/O error: {0}")]
    Io(#[from] io::Error),
    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),
    #[error("HTTP error: {0}")]
    Http(#[from] reqwest::Error),
    #[error("Required executable not found: {0}")]
    MissingTool(String),
    #[error("Command `{program}` failed ({status}): {stderr}")]
    Command { program: String, status: ExitStatus, stderr: String },
    #[error("Invalid input: {0}")]
    Invalid(String),
    #[error("Project file not found: {0}")]
    ProjectNotFound(PathBuf),
    #[error("Provider rejected request: {0}")]
    Provider(String),
}

pub type Result<T> = std::result::Result<T, KklipError>;
