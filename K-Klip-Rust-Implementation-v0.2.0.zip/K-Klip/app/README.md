# Android app module

Compose is the presentation layer. `NativeEngine.kt` is the JNI declaration surface; native implementations live in `engine/src/android.rs`. The UI currently supports project create/list and SAF video import/copy with metadata probe when the Rust library and FFprobe adapter are available.

Android build requires Rust targets, `cargo-ndk`, Android SDK/NDK and Gradle. The Gradle `preBuild` task builds the Rust library for ARM ABIs. This module does not yet bundle Android FFmpeg/FFprobe, yt-dlp runtime, Whisper CLI/model, or a complete preview/render pipeline. See root `BUILD_STATUS.md`.
