package com.klomang.klip

/** Narrow JNI boundary: paths and compact JSON only; media bytes remain on disk. */
object NativeEngine {
    val loaded: Boolean = runCatching { System.loadLibrary("kklip_engine") }.isSuccess
    external fun nativeVersion(): String
    external fun nativeProbe(path: String): String
    external fun nativeCreateProject(root: String, id: String, name: String): String
    external fun nativeListProjects(root: String): String
    external fun nativeDetectScenes(path: String, threshold: Float): String
    external fun nativeYoutubeDownload(url: String, directory: String, format: String): String
    external fun nativePixabaySearch(key: String, query: String): String
}
