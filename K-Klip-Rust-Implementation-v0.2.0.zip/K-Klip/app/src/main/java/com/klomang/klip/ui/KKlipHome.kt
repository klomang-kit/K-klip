package com.klomang.klip.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.klomang.klip.NativeEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

private val Ink = Color(0xFF090D18)
private val Panel = Color(0xFF151D30)
private val Cyan = Color(0xFF54D6E8)
private val Violet = Color(0xFF8B7CFF)

@Composable
fun KKlipHome() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val projectRoot = remember { File(context.filesDir, "projects").apply { mkdirs() } }
    var projectName by remember { mutableStateOf("") }
    var projects by remember { mutableStateOf(listOf<String>()) }
    var status by remember { mutableStateOf("Siap membuat proyek lokal.") }
    var selectedMedia by remember { mutableStateOf("") }
    var mediaInfo by remember { mutableStateOf("") }

    fun refreshProjects() {
        if (!NativeEngine.loaded) { status = "Rust engine belum dimuat. Build native library Android terlebih dahulu."; return }
        runCatching {
            val response = JSONObject(NativeEngine.nativeListProjects(projectRoot.absolutePath))
            if (!response.optBoolean("ok")) error(response.optString("error"))
            val data = response.getJSONArray("data")
            projects = (0 until data.length()).map { i ->
                val item = data.getJSONObject(i)
                "${item.optString("name")}  ·  ${item.optString("id")}"
            }
        }.onFailure { status = it.message ?: "Gagal membaca proyek" }
    }

    LaunchedEffect(Unit) { refreshProjects() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                status = "Menyalin media ke penyimpanan aplikasi…"
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val name = "media-${UUID.randomUUID()}-${uri.lastPathSegment?.takeLast(24) ?: "video"}"
                        val target = File(context.cacheDir, name)
                        context.contentResolver.openInputStream(uri).use { input ->
                            requireNotNull(input) { "Tidak dapat membuka file yang dipilih" }
                            FileOutputStream(target).use { output -> input.copyTo(output) }
                        }
                        target
                    }
                }
                result.onSuccess { file ->
                    selectedMedia = file.absolutePath
                    if (NativeEngine.loaded) {
                        val probe = withContext(Dispatchers.IO) { runCatching { NativeEngine.nativeProbe(file.absolutePath) } }
                        probe.onSuccess { raw ->
                            val json = JSONObject(raw)
                            if (json.optBoolean("ok")) mediaInfo = json.getJSONObject("data").toString(2)
                            else status = "Media tersimpan. Probe gagal: ${json.optString("error")}. Pastikan FFprobe tersedia di build Android."
                        }.onFailure { status = "Media tersimpan; probe gagal: ${it.message}" }
                    } else status = "Media tersimpan di cache aplikasi; Rust JNI belum tersedia."
                }.onFailure { status = "Impor gagal: ${it.message}" }
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, secondary = Violet, background = Ink, surface = Panel,
        onBackground = Color(0xFFF2F5FF), onSurface = Color(0xFFF2F5FF)
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Spacer(Modifier.height(28.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = Violet.copy(alpha = .18f), shape = RoundedCornerShape(16.dp), modifier = Modifier.size(52.dp)) {
                            androidx.compose.foundation.layout.Box(contentAlignment = Alignment.Center) {
                                Text("K", color = Cyan, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
                            }
                        }
                        Column(Modifier.padding(start = 14.dp)) {
                            Text("K-KLIP", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                            Text("RUST VIDEO STUDIO", color = Cyan, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Ubah rekaman menjadi cerita.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Pemrosesan lokal · kontrol kreatif · tanpa backend K-Klip", color = Color(0xFF9DAAC3))
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("BUAT PROYEK", color = Cyan, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            OutlinedTextField(value = projectName, onValueChange = { projectName = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Nama proyek") }, singleLine = true)
                            Button(onClick = {
                                val name = projectName.trim()
                                if (name.isEmpty()) status = "Nama proyek wajib diisi."
                                else if (!NativeEngine.loaded) status = "Rust JNI belum dimuat; proyek belum dapat dibuat dari UI."
                                else {
                                    val id = "p-${UUID.randomUUID().toString().take(8)}"
                                    runCatching { JSONObject(NativeEngine.nativeCreateProject(projectRoot.absolutePath, id, name)) }
                                        .onSuccess { result -> if (result.optBoolean("ok")) { projectName = ""; status = "Proyek berhasil disimpan."; refreshProjects() } else status = result.optString("error") }
                                        .onFailure { status = it.message ?: "Gagal membuat proyek" }
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("Buat proyek lokal") }
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("MEDIA", color = Cyan, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Text("Pilih video dari perangkat. File disalin ke cache privat aplikasi sebelum dianalisis.", color = Color(0xFFB7C2D8))
                            OutlinedButton(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Pilih video") }
                            if (selectedMedia.isNotEmpty()) Text("File: ${File(selectedMedia).name}", color = Color.White)
                            if (mediaInfo.isNotEmpty()) Text(mediaInfo, color = Color(0xFFB7C2D8), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF18243A)), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("STATUS ENGINE", color = Cyan, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                            Text(if (NativeEngine.loaded) runCatching { NativeEngine.nativeVersion() }.getOrDefault("Rust JNI tersedia") else "Rust JNI belum dimuat", fontWeight = FontWeight.SemiBold)
                            Text(status, color = Color(0xFFB7C2D8), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("PROYEK TERAKHIR", fontWeight = FontWeight.Bold)
                        OutlinedButton(onClick = { refreshProjects() }) { Text("Muat ulang") }
                    }
                }
                if (projects.isEmpty()) item { Text("Belum ada proyek tersimpan.", color = Color(0xFF8F9CB5)) }
                items(projects) { project ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                        Text(project, modifier = Modifier.padding(16.dp), fontWeight = FontWeight.Medium)
                    }
                }
                item { Spacer(Modifier.height(28.dp)) }
            }
        }
    }
}
