# K-Klip

Rust-first, clean-room Android video editor. The Rust crate contains the application domain and media/provider operations. Kotlin is limited to Android lifecycle, Compose UI and platform APIs. There is no proprietary K-Klip backend.

## Repository layout

- `engine/src/project.rs`: versioned project data and atomic local project persistence.
- `engine/src/timeline.rs`: typed tracks, clips, split/move/remove operations and duration math.
- `engine/src/media.rs`: FFprobe metadata, FFmpeg thumbnails/audio extraction/enhancement/subtitle burn-in and sequential video export.
- `engine/src/ai.rs`: FFmpeg scene-change and silence analysis, Whisper CLI transcription and transcript keyword extraction.
- `engine/src/network.rs`: yt-dlp process integration, direct Pixabay video API search and HTTPS asset download.
- `engine/src/process.rs`: executable discovery and checked subprocess execution.
- `engine/src/android.rs`: narrow JNI bridge; only paths and compact JSON cross JNI.
- `engine/src/main.rs`: local CLI for diagnostics and engine workflows.
- `app/`: Android Compose shell and JNI consumer.

## Implemented engine commands

```sh
cargo run -p kklip-engine -- doctor
cargo run -p kklip-engine -- probe ./input.mp4
cargo run -p kklip-engine -- project new demo "My first edit"
cargo run -p kklip-engine -- project add-track demo video-main video
cargo run -p kklip-engine -- project add-clip demo video-main clip-1 ./input.mp4 0 5000 0
cargo run -p kklip-engine -- export demo video-main ./output.mp4
cargo run -p kklip-engine -- batch-export demo video-main ./exports
cargo run -p kklip-engine -- scenes ./input.mp4
cargo run -p kklip-engine -- silence ./input.mp4
cargo run -p kklip-engine -- transcribe ./audio.wav ./ggml-base.bin ./captions
cargo run -p kklip-engine -- youtube 'https://www.youtube.com/watch?v=...' ./downloads 720p
cargo run -p kklip-engine -- pixabay-search "$PIXABAY_API_KEY" "city traffic"
```

Project data defaults to `~/.local/share/k-klip`; set `KKLIP_HOME` to change it. FFmpeg/FFprobe, yt-dlp and whisper-cli must be installed and accessible on PATH for the corresponding desktop CLI command.

## Android build

Requirements: Android Studio/SDK, NDK, Rust toolchain, Android Rust targets, `cargo-ndk`, and Gradle. Run `scripts/build-android.sh` or open the Gradle project. The Android Gradle task compiles the Rust JNI library for ARM ABIs.

**Important Android limitation:** this repository does not yet bundle Android-compatible FFmpeg/FFprobe, yt-dlp/Python runtime or whisper-cli/model assets. The JNI engine can report missing executables; desktop CLI integrations are implemented, but those native tools must be ported/bundled and licensed before the corresponding Android functions can run on a phone. Do not assume desktop binaries can execute on Android.

## Verification status

The current environment used to author this snapshot has Java and Git, but no `rustc`, `cargo`, Gradle executable, Android SDK/NDK, or adb. Therefore no Rust compile/test, Android build, APK installation, or device test has been claimed. Run `cargo fmt --all -- --check` and `cargo test --workspace` in a Rust-enabled environment before merging.

## Not yet implemented

Face detection/tracking and smart reframe; model-based semantic highlight ranking; animated caption templates; multi-track compositing, transitions, keyframes and overlays; timeline preview/scrubbing; batch export queue; resumable/cancellable downloads; encrypted API-key storage UI; Android FFmpeg/Whisper/yt-dlp packaging; robust project migrations and crash recovery. These are explicitly tracked in `docs/ROADMAP.md` and are not represented as completed.

## Licensing

Original K-Klip-authored files are MIT. Third-party dependencies, command-line tools, models and downloaded media retain their own licenses and terms. See `THIRD_PARTY_NOTICES.md`. This is a clean-room implementation; the MIT notice does not relicense third-party software.
